#!/usr/bin/env python3
"""Independent, stdlib-only audit of fresh Qwen B/C records; never runs workloads."""
import argparse
import collections
import csv
import datetime
import hashlib
import json
import math
import re
import shlex
import statistics
from pathlib import Path

REPO = Path('/root/Liger-Kernel')
ROOT = Path('/tmp/qwen-v2-validation')
MODELS = ('qwen3', 'qwen3_5', 'qwen3_moe', 'qwen3_5_moe')
MODEL_IDS = dict(zip(MODELS, ('Qwen/Qwen3-8B', 'Qwen/Qwen3.5-9B', 'Qwen/Qwen3-30B-A3B', 'Qwen/Qwen3.5-35B-A3B')))
LIGER = 'liger_kernel.transformers.rms_norm.LigerRMSNorm.forward'
CASE = re.compile(r'^(qwen3(?:_5)?(?:_moe)?)_(norm|attention|model)_b(1|4)_s(128|2048|8192)_([BC])\.json$')
SHA = re.compile('[0-9a-f]{64}')

def read(path):
    return json.loads(path.read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def geometry(c, gemma, moe):
    h, d, q, k, n, v = (c[x] for x in ('hidden_size','head_dim','num_attention_heads','num_key_value_heads','num_hidden_layers','vocab_size'))
    attn = h*((3 if gemma else 2)*q*d+2*k*d)+2*d
    if moe:
        mlp = 3*h*c['num_experts']*c['moe_intermediate_size']+h*c['num_experts']
        if gemma:
            mlp += 3*h*c['shared_expert_intermediate_size']+h
    else:
        mlp = 3*h*c['intermediate_size']
    layer_types = c.get('layer_types', ['full_attention']*n)
    full_indices = [i for i,t in enumerate(layer_types) if t == 'full_attention']
    linear = 0
    if gemma:
        kd = c['linear_num_key_heads']*c['linear_key_head_dim']
        vd = c['linear_num_value_heads']*c['linear_value_head_dim']
        nv = c['linear_num_value_heads']
        linear = h*(2*kd+3*vd+2*nv)+(2*kd+vd)*c['linear_conv_kernel_dim']+2*nv+c['linear_value_head_dim']
    total = 2*v*h+h+n*(2*h+mlp)+len(full_indices)*attn+(n-len(full_indices))*linear
    return {'parameter_count':total, 'attention_parameters':attn, 'full_indices':full_indices, 'hidden_size':h, 'head_dim':d, 'q_heads':q, 'k_heads':k, 'depth':n}

def audit_directory(directory):
    errors, failed_cases, pending, rows = [], [], [], []
    non_measurement_cases = []
    training_directory = directory.name.startswith(('train-', 'training-'))
    probe_directory = 'probe' in directory.name
    def check(ok, context, message):
        if not ok:
            errors.append({'context':context, 'issue':message})
    def equal(a,b,context,label):
        check(a==b, context, f'{label}: actual={a!r}, expected={b!r}')
    def close(a,b,context,label):
        check(isinstance(a,(int,float)) and math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-12),context,f'{label}: actual={a!r}, expected={b!r}')
    paths = sorted(p for p in directory.glob('*.json') if CASE.fullmatch(p.name) or p.name == 'probe.json')
    records = {}
    for p in paths:
        try:
            records[p.name] = read(p)
        except (OSError,ValueError) as e:
            errors.append({'context':p.name, 'issue':str(e)})
    status = collections.Counter(d.get('status','missing') for d in records.values())
    source = read(directory/'source.json') if (directory/'source.json').exists() else {}
    env = read(directory/'environment.json') if (directory/'environment.json').exists() else {}
    run_error = read(directory/'run_error.json') if (directory/'run_error.json').exists() else None
    execution_status = read(directory/'execution-status.json') if (directory/'execution-status.json').exists() else None
    command = env.get('command', (run_error or {}).get('command', []))
    command_args = shlex.split(command) if isinstance(command, str) else command
    training_shapes = [(4, 2048), (1, 8192)] if '--primary' in command_args else [(b, s) for b in (1, 4) for s in (128, 2048, 8192)]
    complete = (directory/'environment.json').exists()
    execution_state = 'blocked' if run_error is not None else ('completed' if complete else 'awaiting_results')
    script_hash = source.get('source_sha256',{}).get('benchmark/scripts/benchmark_qwen_qk_norm.py')
    check(source.get('baseline_ref','') == '', directory.name, 'Benchmark must use current implementation, not baseline source replacement')
    if source:
        check(bool(SHA.fullmatch(script_hash or '')),directory.name,'Missing source benchmark script hash')
    if env:
        equal(env.get('exit_code'),0,directory.name,'remote exit code')
        check('H100' in env.get('gpu',''),directory.name,'remote GPU not H100')
    if training_directory and env:
        equal(env.get('gpu_count'),8,directory.name,'physical GPU count')
        for package,expected_version in {'torch':'2.9.1','triton':'3.5.1','transformers':'5.15.1','flash-linear-attention':'0.5.2','fla-core':'0.5.2','causal-conv1d':'1.7.0','tilelang':'0.1.14','nvidia-cuda-nvcc':'13.0.88'}.items():
            equal(str(env.get('packages',{}).get(package,'')).split('+')[0],expected_version,directory.name,f'training package {package}')
    if training_directory and not probe_directory:
        # One allocation may return several models; validate the models actually
        # represented here, not all four models in every directory.
        actual_models={d.get('model') for d in records.values() if d.get('model') in MODELS}
        if not actual_models:
            suffix=directory.name.split('-',1)[1]
            known_model=next((m for m in sorted(MODELS,key=len,reverse=True) if suffix==m or suffix.startswith(m+'-')),None)
            if known_model is not None:actual_models.add(known_model)
        expected={f'{model}_model_b{b}_s{s}_{g}.json' for model in actual_models for b,s in training_shapes for g in ('B','C')}
        pending.extend(sorted(expected-set(records)))
        check(not (set(records)-expected),directory.name,f'Unexpected cases in {len(training_shapes)}-shape training matrix')
        if complete:check(not pending,directory.name,f'Missing completed training cases: {pending}')
    if directory.name.startswith('kernels-'):
        model = directory.name[len('kernels-'):]
        expected = {f'{model}_{level}_b{b}_s{s}_{g}.json' for level in ('norm','attention') for b in (1,4) for s in (128,2048,8192) for g in ('B','C')}
        missing = sorted(expected-set(records))
        pending.extend(missing)
        check(not (set(records)-expected), directory.name,'Unexpected cases in one-GPU matrix')
        if complete:
            check(not missing,directory.name,f'Missing completed-matrix cases: {missing}')
            equal(env.get('gpu_count'),1,directory.name,'physical GPU count')
    models = {}
    valid_successes = {}
    for name,d in records.items():
        if (match := CASE.fullmatch(name)) is not None:
            m,level,b,s,g = match.groups(); b=int(b);s=int(s)
        else:
            m,level,b,s,g = (d.get(key) for key in ('model','level','batch_size','seq_len','group'))
            check(d.get('probe_only') is True,name,'probe file must declare probe_only')
            check(m in MODELS and level == 'model' and b in (1,4) and s in (128,2048,8192) and g in ('B','C'),name,'probe metadata must identify a known case')
        if d.get('probe_only') and d.get('status') == 'ok':
            check(False,name,'Probe-only execution must not be labelled as measured ok')
        if d.get('status') != 'ok':
            non_measurement_cases.append({'case':name,'status':d.get('status')})
            check(not d.get('measurements'),name,'Non-ok case must not publish timing measurements')
        if d.get('status') not in ('ok','probed'):
            failed_cases.append({'case':name,'status':d.get('status'),'error':d.get('error'), 'rank_failures':d.get('rank_failures',[])})
            continue
        start_errors = len(errors)
        equal(d.get('returncode',0),0,name,'successful process exit code')
        check(not d.get('rank_failures'),name,'Successful case has rank failure records')
        cfgpath=REPO/'benchmark/data/qwen_qk_norm/configs'/f'{m}.json'
        saved=read(cfgpath); official=saved['config'].get('text_config',saved['config'])
        actual=d.get('model_config',{})
        geo=geometry(official, '_5' in m, 'moe' in m);models[m]=geo
        for key in ('model','level','batch_size','seq_len','group'):
            equal(d.get(key),dict(model=m,level=level,batch_size=b,seq_len=s,group=g)[key],name,key)
        equal(d.get('model_id'),MODEL_IDS[m],name,'official model ID')
        equal(d.get('config_sha256'),digest(cfgpath),name,'pinned official config digest')
        equal(d.get('config_revision'),saved['revision'],name,'official config revision')
        equal(d.get('config_source'),saved['source'],name,'official config source')
        for key in ('hidden_size','head_dim','num_attention_heads','num_key_value_heads','num_hidden_layers','vocab_size','intermediate_size','moe_intermediate_size','num_experts','num_experts_per_tok','shared_expert_intermediate_size','layer_types','linear_num_key_heads','linear_num_value_heads','linear_key_head_dim','linear_value_head_dim'):
            if key in official:
                actual_value = actual.get('num_local_experts') if m == 'qwen3_moe' and key == 'num_experts' else actual.get(key)
                equal(actual_value,official[key],name,f'official architecture {key}')
        equal(d.get('parameter_count'),geo['parameter_count'],name,'independently computed full text parameter count')
        expected_names={f'model.layers.{i}.self_attn.{norm}_norm' for i in geo['full_indices'] for norm in ('q','k')}
        bindings=d.get('bindings',{})
        equal(set(bindings),expected_names,name,'binding coverage across full-attention layers')
        equal(d.get('qk_norm_count'),len(expected_names),name,'Q/K norm count')
        for key,value in bindings.items():
            check(value==LIGER if g=='C' else value.startswith(f'transformers.models.{m}.modeling_{m}.') and value.endswith('RMSNorm.forward'),name,f'Incorrect {g} binding: {key}={value}')
        gemma='_5' in m
        ns=d.get('norm_settings',{})
        for key,value in dict(offset=1 if gemma else 0,casting_mode='gemma' if gemma else 'llama',in_place=not gemma).items():
            equal(ns.get(key),value,name,f'norm {key}')
        settings=d.get('settings',{})
        for key,value in dict(dtype='bfloat16',attention_backend='sdpa',torch_compile=False,tf32=False,rms_norm=True,swiglu=True,rope=False,cross_entropy=False,fused_linear_cross_entropy=True,use_cache=False).items():
            equal(settings.get(key),value,name,f'fixed setting {key}')
        re=d.get('environment',{})
        for key,value in dict(torch='2.9.1',cuda='12.8',triton='3.5.1',transformers='5.15.1').items():
            check(str(re.get(key,'')).split('+')[0]==value,name,f'unexpected runtime {key}={re.get(key)}')
        check('H100' in re.get('gpu',''),name,'case GPU not H100')
        for key in ('initial_weights_sha256','input_checksum','buffer_sha256'):
            check(bool(SHA.fullmatch(d.get(key,''))),name,f'invalid hash {key}')
        if gemma:
            kernels=d.get('linear_attention_kernels',{})
            check(kernels.get('torch_chunk_gated_delta_rule','').startswith('fla.'),name,'FLA not actually bound')
            check(kernels.get('causal_conv1d_fn','').startswith('causal_conv1d.'),name,'causal-conv1d not actually bound')
        if level in ('norm','attention'):
            equal(settings.get('world_size'),1,name,'world size')
            equal(settings.get('gradient_checkpointing'),False,name,'checkpointing')
            equal(d.get('materialized_parameter_count'),geo['attention_parameters'],name,'independent attention parameter count')
            equal(d.get('weight_hash_scope'),'isolated_attention',name,'weight hash scope')
            if level=='norm':
                for kind,heads,factor in (('q',geo['q_heads'],2 if gemma else 1),('k',geo['k_heads'],1)):
                    layout=d.get('layouts',{}).get(kind,{})
                    dim=geo['head_dim']; expected_stride=[s*heads*dim*factor,heads*dim*factor,dim*factor,1]
                    equal(layout.get('shape'),[b,s,heads,dim],name,f'{kind} real shape')
                    equal(layout.get('stride'),expected_stride,name,f'{kind} native projection stride')
                    equal(layout.get('contiguous'),factor==1,name,f'{kind} contiguous flag')
        else:
            equal(settings.get('world_size'),8,name,'world size')
            hardware=d.get('rank_hardware',[])
            check(len(hardware)==8,name,'must record all 8 GPU ranks')
            equal(sorted(gpu.get('rank') for gpu in hardware),list(range(8)),name,'unique hardware rank IDs')
            for gpu in hardware:
                equal(gpu.get('name'),'NVIDIA H100 80GB HBM3',name,f'rank {gpu.get("rank")} GPU model')
                check(78*2**30 <= gpu.get('total_memory_bytes',0) <= 81*2**30,name,'GPU capacity must be H100 80GB, not NVL')
            check(len({(gpu.get('name'),gpu.get('total_memory_bytes')) for gpu in hardware})==1,name,'all 8 GPU hardware configurations must match')
            if hardware:equal(re.get('gpu_memory_bytes'),hardware[0]['total_memory_bytes'],name,'case memory matches hardware')
            for key in ('parameter_master_dtype','gradient_reduce_dtype','optimizer_state_dtype'):
                equal(settings.get(key),'float32',name,f'training precision setting {key}')
            equal(settings.get('fsdp'),'FSDP2 decoder+root, reshard_after_forward=True',name,'FSDP wrapping/resharding')
            equal(settings.get('optimizer'),'AdamW(lr=1e-5, foreach=False, fused=False)',name,'optimizer algorithm')
            equal(d.get('weight_hash_scope'),'All actual FP32 local shards, combined in rank order.',name,'distributed hash scope')
            equal(settings.get('gradient_checkpointing'),True,name,'checkpointing')
            equal(settings.get('checkpoint_use_reentrant'),False,name,'checkpointing type')
            equal(d.get('verified_precision'),dict(master='float32',gradient='float32',exp_avg='float32',exp_avg_sq='float32'),name,'verified precision')
            for key,combined in (('rank_initial_weights_sha256','initial_weights_sha256'),('rank_input_sha256','input_checksum')):
                hashes=d.get(key,[])
                check(len(hashes)==8 and all(SHA.fullmatch(x) for x in hashes),name,f'{key} must cover 8 ranks')
                equal(hashlib.sha256(''.join(hashes).encode()).hexdigest(),d.get(combined),name,f'{key} combination')
            states=d.get('optimizer_state_bytes_per_rank',[])
            check(len(states)==8 and all(x>0 for x in states),name,'missing optimizer allocation ranks')
            equal(sum(states),geo['parameter_count']*8,name,'actual Adam moment bytes (2 FP32 moments)')
            check(all(x==geo['parameter_count'] for x in states),name,'each rank has its full equal shard of both Adam moments')
            if gemma:
                equal(d.get('observed_delta_compute_parameter_dtypes'),dict(A_log='torch.bfloat16',dt_bias='torch.bfloat16'),name,'actual delta compute parameter dtype')
                dispatch=d.get('hybrid_backend_dispatch',{})
                equal(dispatch.get('required'),'common:chunk_bwd_dqkwg:tilelang',name,'required supported hybrid backward')
                check('common:chunk_bwd_dqkwg:tilelang' in dispatch.get('executed',[]),name,'TileLang backward must actually execute')
                equal(dispatch.get('FLA_TILELANG'),'1',name,'explicit TileLang selection')
                equal(dispatch.get('tilelang_version'),'0.1.14',name,'actual TileLang version')
            if d.get('status')=='probed':
                losses=d.get('probe_loss_per_rank',[])
                check(len(losses)==8 and all(math.isfinite(x) for x in losses),name,'probe losses')
        if d.get('status')=='ok':
            measurements=d.get('measurements',{})
            equal(set(measurements),{'q','k','qk'} if level=='norm' else {'attention'} if level=='attention' else {'training_step'},name,'measurement components')
            for component,metrics in measurements.items():
                modes={'full':metrics} if component=='training_step' else metrics
                equal(set(modes),{'full'} if component=='training_step' else {'forward','backward','full'},name,f'{component} modes')
                for mode,stat in modes.items():
                    context=f'{name}:{component}:{mode}'; samples=stat.get('round_ms',[])
                    check(len(samples)>=5 and all(math.isfinite(x) and x>0 for x in samples),context,'at least 5 positive finite rounds')
                    equal(len(samples),d.get('rounds',5),context,'recorded rounds equal requested rounds')
                    if len(samples)>=2:
                        for key,value in dict(median_ms=statistics.median(samples),min_ms=min(samples),max_ms=max(samples),stdev_ms=statistics.stdev(samples)).items():
                            close(stat.get(key),value,context,key)
                    check(stat.get('peak_allocated_bytes',0)>0,context,'missing peak allocated bytes')
                    equal(stat.get('warmup_iterations'),3,context,'excluded warmup')
                    equal(stat.get('repetitions_per_round'),20 if level=='norm' else 10 if level=='attention' else 3,context,'repetitions')
                    if level=='model':
                        peaks=stat.get('peak_allocated_bytes_per_rank',[])
                        check(len(peaks)==8 and all(x>0 for x in peaks),context,'8-rank allocated peaks')
                        if peaks:equal(stat.get('peak_allocated_bytes'),max(peaks),context,'peak is max rank allocated')
                        for i,peak in enumerate(peaks):
                            if i<len(hardware):check(peak<=hardware[i]['total_memory_bytes'],context,f'allocated rank{i} exceeds physical capacity')
                            if i<len(states):check(peak>=states[i]*2,context,f'allocated rank{i} below FP32 master+grad+Adam lower bound')
                        equal(stat.get('timing'),'Synchronized wall time, maximum rank; includes zero_grad, forward, backward, optimizer and FSDP communication.',context,'distributed timing meaning')
                        close(stat.get('tokens_per_second'),settings['world_size']*b*s*1000/stat['median_ms'],context,'global tokens/sec')
                        event_rounds=stat.get('cuda_event_round_ms',[])
                        check(len(event_rounds)==len(samples) and all(math.isfinite(x) and x>0 for x in event_rounds),context,'positive matching diagnostic event rounds')
        valid_successes[name]=len(errors)==start_errors
    paired=0
    for name,before in records.items():
        if not name.endswith('_B.json'):continue
        cname=name[:-7]+'_C.json'
        after=records.get(cname)
        if after is None:continue
        if before.get('status')!='ok' or after.get('status')!='ok':continue
        paired+=1
        for key in ('initial_weights_sha256','input_checksum','buffer_sha256','config_sha256','model_id','config_source','config_revision','model_config','environment','settings','norm_settings','layouts','linear_attention_kernels','parameter_count','materialized_parameter_count','rank_initial_weights_sha256','rank_input_sha256','verified_precision','optimizer_state_bytes_per_rank','observed_delta_compute_parameter_dtypes','rank_hardware','hybrid_backend_dispatch'):
            equal(before.get(key),after.get(key),name,f'B/C {key}')
        equal(set(before.get('bindings',{})),set(after.get('bindings',{})),name,'B/C binding keys')
        for component,measurements in before['measurements'].items():
            modes={'full':measurements} if component=='training_step' else measurements
            for mode,bm in modes.items():
                cm=after['measurements'][component]
                if component!='training_step':cm=cm[mode]
                rows.append(dict(global_tokens_per_step=before['settings']['world_size']*before['batch_size']*before['seq_len'] if before['level']=='model' else None,B_tokens_per_second=bm.get('tokens_per_second'),C_tokens_per_second=cm.get('tokens_per_second'),B_peak_allocated_bytes=bm['peak_allocated_bytes'],C_peak_allocated_bytes=cm['peak_allocated_bytes'],model=before['model'],level=before['level'],batch_size=before['batch_size'],seq_len=before['seq_len'],component=component,mode=mode,B_median_ms=bm['median_ms'],C_median_ms=cm['median_ms'],B_over_C=bm['median_ms']/cm['median_ms'],B_round_range=[min(bm['round_ms']),max(bm['round_ms'])],C_round_range=[min(cm['round_ms']),max(cm['round_ms'])],round_ranges_overlap=max(min(bm['round_ms']),min(cm['round_ms']))<=min(max(bm['round_ms']),max(cm['round_ms']))))
    for csvpath in directory.glob('*_comparison.csv'):
        csvrows=list(csv.DictReader(csvpath.open()))
        key=lambda r:(r['model'],r['level'],int(r['batch_size']),int(r['seq_len']),r['component'],r['mode'])
        csv_model=csvpath.name.removesuffix('_comparison.csv')
        computed={key(row):row for row in rows if row['model']==csv_model}
        equal(set(map(key,csvrows)),set(computed),csvpath.name,'CSV row coverage')
        for row in csvrows:
            expected=computed.get(key(row))
            if expected:
                if expected['level']=='model':
                    for field in ('B_tokens_per_second','C_tokens_per_second','B_peak_allocated_bytes','C_peak_allocated_bytes'):
                        close(float(row[field]),expected[field],csvpath.name,str(key(row))+':'+field)
                for field in ('B_median_ms','C_median_ms','B_over_C'):
                    close(float(row[field]),expected[field],csvpath.name,str(key(row))+':'+field)
    per_model_status={}
    for model in sorted({d.get('model') for d in records.values() if d.get('model') in MODELS}):
        per_model_status[model]=dict(collections.Counter(d.get('status','missing') for d in records.values() if d.get('model')==model))
    blocked_missing_cases = pending if execution_state == 'blocked' else []
    if execution_state == 'blocked':
        pending = []
    return dict(directory=str(directory),complete=complete,execution_state=execution_state,blocking_error=run_error,reported_execution_status=execution_status,status_counts=dict(status),per_model_status=per_model_status,case_count=len(records),executed_nonprobe_case_count=sum(not d.get('probe_only',False) and d.get('status') not in ('probed','validated') for d in records.values()),successful_pairs=paired,pending_cases=pending,blocked_missing_cases=blocked_missing_cases,failed_cases=failed_cases,non_measurement_cases=non_measurement_cases,audit_errors=errors,source_script_sha256=script_hash,models=models,comparisons=rows,successful_cases_audited=sum(valid_successes.values()),measured_cases_audited=sum(valid and records[name].get('status')=='ok' for name,valid in valid_successes.items()))

def main():
    global ROOT, REPO
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directories',nargs='*',type=Path,help='Optional run directories, absolute or relative to --root.')
    parser.add_argument('--root',type=Path,default=ROOT,help='Fresh raw run root, including an extracted archive root.')
    parser.add_argument('--repo',type=Path,default=Path.cwd(),help='Repository root containing benchmark/data/qwen_qk_norm/configs; defaults to current directory.')
    parser.add_argument('--output',type=Path,help='Audit JSON output; defaults to <root>/fresh-benchmark-audit.json.')
    args=parser.parse_args()
    ROOT=args.root.resolve(); REPO=args.repo.resolve()
    if not (REPO/'benchmark/data/qwen_qk_norm/configs').is_dir():
        parser.error('Run from the Liger-Kernel repository root or pass --repo /path/to/Liger-Kernel.')
    if args.output is None:args.output=ROOT/'fresh-benchmark-audit.json'
    directories=[d if d.is_absolute() else ROOT/d for d in args.directories] if args.directories else [ROOT/f'kernels-{m}' for m in MODELS]+sorted(d for d in ROOT.glob('train-*') if d.is_dir())
    reports=[]
    for d in directories:
        try:reports.append(audit_directory(d))
        except Exception as e:reports.append(dict(directory=str(d),audit_errors=[{'issue':f'Auditor exception {type(e).__name__}: {e}'}]))
    summary=dict(generated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope=f'Fresh benchmark runs under {ROOT}; historical measurements excluded.',raw_root=str(ROOT),repository_root=str(REPO),directories=reports,audit_error_count=sum(len(d.get('audit_errors',[])) for d in reports),failed_case_count=sum(len(d.get('failed_cases',[])) for d in reports))
    combined_status=collections.Counter()
    for report in reports:combined_status.update(report.get('status_counts',{}))
    summary.update(status_counts=dict(combined_status),case_count=sum(combined_status.values()),executed_nonprobe_case_count=sum(d.get('executed_nonprobe_case_count',0) for d in reports),measured_case_count=combined_status.get('ok',0),successful_pairs=sum(d.get('successful_pairs',0) for d in reports),comparison_count=sum(len(d.get('comparisons',[])) for d in reports),blocked_directories=[d['directory'] for d in reports if d.get('execution_state')=='blocked'])
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='directories'}))
    for report in reports:print(json.dumps({k:v for k,v in report.items() if k not in ('comparisons','pending_cases','models')}))

if __name__=='__main__':main()
